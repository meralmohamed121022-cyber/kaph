import pandas as pd
import json
import re

# ✅ Path الملف الصحيح
excel_path = r'C:\Users\HP\offers gtest\offers tegara\Offers.xlsx'

print("📖 جاري قراءة الملف...")
df = pd.read_excel(excel_path)

def fix_percentage_desc(text):
    text = str(text).strip()
    if text == 'nan': return ""
    try:
        val = float(text)
        if 0 < val < 1:
            return f"{int(round(val * 100))}%"
    except:
        pass
    return text

df['الباركود'] = df['الباركود'].astype(str).str.strip()
df['الوصف'] = df['الوصف'].apply(fix_percentage_desc)
df['offerPrice'] = df['offerPrice'].astype(str).str.strip()

offers_grouped = {}
for _, row in df.iterrows():
    desc = row['الوصف']
    if not desc or desc == 'nan': continue
    barcode = row['الباركود']
    price = row['offerPrice']
    if price == 'nan': price = ""
    
    if desc not in offers_grouped:
        offers_grouped[desc] = {'codes': [], 'prices': {}}
    if barcode not in offers_grouped[desc]['codes']:
        offers_grouped[desc]['codes'].append(barcode)
    offers_grouped[desc]['prices'][barcode] = price

def format_offer_ar(text):
    text_lower = text.lower()
    # استخراج كل الأرقام (سواء نسبة أو سعر)
    nums = re.findall(r'\d+\.?\d*', text)
    
    # 1. عروض السعر المحدد (SAR)
    if 'sar' in text_lower:
        if '2nd' in text_lower or 'second' in text_lower:
            price = nums[-1] if nums else ""
            return f"اشتري حبة واحصل على الثانية بسعر {price} ريال"
        else:
            price = nums[-1] if nums else ""
            return f"اشتري حبة بسعر {price} ريال"

    # 2. عروض المجانا (1+1, 2+1)
    if '+' in text or 'free' in text or 'مجانا' in text:
        if len(nums) >= 2:
            h_buy = "حبه" if nums[0] == '1' else f"{nums[0]} حبات"
            h_get = "حبه" if nums[1] == '1' else f"{nums[1]} حبات"
            if nums[0] == '1' and nums[1] == '1':
                return "اشتري حبه واحصل على الثانية مجانا"
            return f"عرض {h_buy} + {h_get} مجانا"
        return "اشتري حبه واحصل على حبه مجانا"

    # 3. الخصم المئوي %
    if '%' in text:
        p = nums[0] if nums else ""
        if any(x in text_lower for x in ["second", "2nd", "ثانية", "الحبه"]):
            return f"خصم {p}% على الحبة الثانية"
        return f"خصم مباشر {p}%"
    
    return text

def format_offer_en(text):
    text_lower = text.lower()
    nums = re.findall(r'\d+\.?\d*', text)
    
    if 'sar' in text_lower:
        if '2nd' in text_lower or 'second' in text_lower:
            return f"Buy 1 Get 2nd @ {nums[-1]} SAR"
        return f"Buy 1 @ {nums[-1]} SAR"

    if '+' in text or 'free' in text:
        if len(nums) >= 2: return f"{nums[0]}+{nums[1]} free"
        return "1+1 free"

    if '%' in text:
        p = nums[0] if nums else ""
        if any(x in text_lower for x in ["second", "2nd", "ثانية"]):
            return f"{p}% off on 2nd"
        return f"{p}% off"
    
    return text[:25]

def get_style_class(text):
    text_lower = text.lower()
    if '%' in text:
        nums = re.findall(r'\d+', text)
        p = nums[0] if nums else "0"
        if any(x in text_lower for x in ["second", "2nd", "ثانية"]):
            return f"offer-{p}-second"
        return f"offer-{p}-direct"
    if any(x in text_lower for x in ["free", "مجانا", "+", "sar"]):
        return "offer-buy-get"
    return "offer-custom"

offersDB = []
for description, data in offers_grouped.items():
    offersDB.append({
        "offerType": format_offer_en(description),
        "offerTypeAR": format_offer_ar(description),
        "codes": data['codes'],
        "styleClass": get_style_class(description),
        "badgeClass": get_style_class(description),
        "offerPrice": data['prices']
    })

output_path = r'C:\Users\HP\offers gtest\offers tegara\offersfromtegara.json'
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(offersDB, f, ensure_ascii=False, indent=2)

print(f"🚀 تم الإصلاح! الملف جاهز بـ {len(offersDB)} عرض.")
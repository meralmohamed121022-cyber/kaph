import pandas as pd
import json
import re
from deep_translator import GoogleTranslator

# ✅ Path الملف الصحيح
excel_path = r'C:\Users\HP\offers gtest\offers tegara\Offers.xlsx'

print("📖 جاري قراءة الملف...")
df = pd.read_excel(excel_path)
df = df.dropna()

# 🔥 قراءة الأعمدة الثلاثة بالأسماء الصحيحة
df['الباركود'] = df['الباركود'].astype(str).str.strip()
df['offerPrice'] = df['offerPrice'].astype(float)  # ✅ العمود B
df['الوصف'] = df['الوصف'].astype(str).str.strip()

# 🔥 تجميع حسب الوصف مع الباركود والسعر
offers_grouped = df.groupby('الوصف').apply(
    lambda x: {
        'codes': x['الباركود'].tolist(),
        'prices': dict(zip(x['الباركود'], x['offerPrice']))  # ✅ {barcode: price}
    }
).to_dict()

NUMBER_MAP = {
    'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5',
    'six': '6', 'seven': '7', 'eight': '8', 'nine': '9', 'ten': '10',
    'twenty': '20', 'thirty': '30', 'forty': '40', 'fifty': '50',
    'sixty': '60', 'seventy': '70', 'eighty': '80', 'ninety': '90'
}

def numbers_to_digits(text):
    for word, num in NUMBER_MAP.items():
        text = re.sub(rf'\b{word}\b', num, text, flags=re.IGNORECASE)
    return text

def replace_habe_to_pc(ar_text):
    """حبه → 1 PC, حبتان → 2 PCs قبل الترجمة"""
    replacements = {
        r'\bحبه\b': '1 PC',
        r'\bالحبه?\b': '1 PC',
        r'\bحبتان?\b': '2 PCs',
        r'\bثلاث?\s*حبات?\b': '3 PCs',
        r'\bأربع?\s*حبات?\b': '4 PCs',
        r'\bخمس?\s*حبات?\b': '5 PCs',
        r'مجانا?': 'free',
        r'مجاناً': 'free'
    }
    for pattern, replacement in replacements.items():
        ar_text = re.sub(pattern, replacement, ar_text, flags=re.IGNORECASE)
    return ar_text

def shorten_offer(en_translated):
    en_lower = en_translated.lower()

    # Buy X get Y free
    if 'free' in en_lower:
        nums = re.findall(r'\d+', en_translated)
        if len(nums) >= 2:
            return f"{nums[0]}+{nums[1]} free"
        elif len(nums) == 1:
            return f"{nums[0]}+1 free"
        return "1+1 free"

    # X% discount on second
    if '%' in en_translated and any(word in en_lower for word in ['second', 'sec']):
        percent = re.findall(r'\d+', en_translated)[0]
        has_pc = bool(re.search(r'\bpc\b', en_lower)) or ('pcs' in en_lower)
        return f"{percent}% dis sec" + (" pc" if has_pc else "")

    # X% discount/off
    if '%' in en_translated:
        percent = re.findall(r'\d+', en_translated)[0]
        return f"{percent}% off"

    return en_translated[:15] + '...'

def translate_arabic_to_english(ar_text):
    try:
        ar_processed = replace_habe_to_pc(ar_text)
        translator = GoogleTranslator(source='ar', target='en')
        en_text = translator.translate(ar_processed)
        en_text = en_text.replace('pill', 'PC').replace('pills', 'PCs')
        en_text = numbers_to_digits(en_text)
        return shorten_offer(en_text)
    except Exception as e:
        print(f"⚠️ خطأ: {ar_text}")
        return shorten_offer(replace_habe_to_pc(ar_text))

def get_style_class(ar_description):
    desc = ar_description.strip()
    nums = re.findall(r'\d+', desc)
    percent = int(nums[0]) if nums else 0

    if "خصم" in desc and "%" in desc and "على الحبه" not in desc:
        return f"offer-{percent}-direct"
    elif "على الحبه" in desc or "الحبه الثانيه" in desc:
        return f"offer-{percent}-second"
    elif any(x in desc for x in ["حبة", "حبتان", "مجانا"]):
        return "offer-buy-get"
    return "offer-custom"

offersDB = []
print("\n🔄 حبه=PC + ترجمة + أرقام + اختصار...")

for i, (ar_description, data) in enumerate(offers_grouped.items(), 1):
    en_description = translate_arabic_to_english(ar_description)

    offer_obj = {
        "offerType": en_description,
        "offerTypeAR": ar_description,
        "codes": data['codes'],
        "styleClass": get_style_class(ar_description),
        "badgeClass": get_style_class(ar_description),
        "offerPrice": data['prices']  # 🔥 السعر من Excel مباشرةً
    }
    offersDB.append(offer_obj)
    print(f"[{i}] {ar_description[:30]}... → {en_description}")

def sort_key(offer):
    nums = re.findall(r'\d+', offer["offerTypeAR"])
    percent = int(nums[0]) if nums else 999
    if "direct" in offer["styleClass"]:
        return percent
    elif "buy-get" in offer["styleClass"]:
        return 0
    return 999

offersDB.sort(key=sort_key)

# ✅ الـ Path المظبوط - لازم يكون اسم ملف مش مجلد!
output_path = r'C:\Users\HP\offers gtest\offers tegara\offersfromtegara.json'

with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(offersDB, f, ensure_ascii=False, indent=2)

print("\n✅ حبه=1 PC مظبوط 100%!")
print(f"📦 {len(offersDB)} عرض مثالي مع الأسعار! 💰")
print(f"📁 تم الحفظ في: {output_path}")
